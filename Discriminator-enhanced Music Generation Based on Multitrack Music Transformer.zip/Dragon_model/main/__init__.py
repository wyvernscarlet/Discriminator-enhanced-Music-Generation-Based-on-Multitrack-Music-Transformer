"""MMT model."""
